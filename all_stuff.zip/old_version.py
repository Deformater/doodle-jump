import os
import sys
import random

import pygame


pygame.init()
size = width, height = 471, 719
screen = pygame.display.set_mode(size)
pygame.display.set_caption('Doodle jump')
screen.fill((255, 255, 255))
a = 0


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def generate():
    global a
    x = Platform(width // 2, height - 25)
    a = height - 26
    for i in range(random.randint(30, 40)):
        a = random.randint(a - 304 + dude.rect.h + x.rect.h, a - x.rect.h - 1)
        p = random.choice(P)
        x = PLATFORM[p](random.randint(0, width - x.rect.w), a)


class Camera:
    # зададим начальный сдвиг камеры
    def __init__(self):
        self.dy = height
        self.delta = 0

    # сдвинуть объект obj на смещение камеры
    def apply(self, obj):
        obj.rect.y += 1

    # позиционировать камеру на объекте target
    def update(self, target):
        i = 0
        self.delta = target.delta - 324
        while i < target.delta - 324:
            for sprite in platforms:
                camera.apply(sprite)
            camera.apply(dude)
            i += 1


class Background(pygame.sprite.Sprite):
    image = load_image("background.png")

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Background.image
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = 0
        self.rect.y = 0


class Platform(pygame.sprite.Sprite):
    image = load_image("platform_classic.png")

    def __init__(self, x, y):
        super().__init__(platforms)
        self.image = Platform.image
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = x
        self.rect.y = y

    def update(self, arg=False):
        global a
        if not arg:
            if self.rect.y > height:
                a = random.randint(a - 304 + dude.rect.h + self.rect.h, a - self.rect.h - 1)
                self.rect.x, self.rect.y = random.randint(0, width - self.rect.w), a


class PlatformCrush(Platform):
    image = load_image("platform_crush.png")

    def __init__(self, x_coords, y_coords):
        super().__init__(x_coords, y_coords)
        self.image = PlatformCrush.image
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)

    def update(self, arg=False):
        global a
        if not arg:
            if self.rect.y > height:
                a = random.randint(a - 304 + dude.rect.h + self.rect.h, a - self.rect.h - 1)
                self.rect.x, self.rect.y = random.randint(0, width - self.rect.w), a
        else:
            a = random.randint(a - 304 + dude.rect.h + self.rect.h, a - self.rect.h - 1)
            self.rect.x, self.rect.y = random.randint(0, width - self.rect.w), a


class PlatformSpring(Platform):
    image = load_image("platform_spring.png")

    def __init__(self, x, y):
        super().__init__(x, y)
        self.image = PlatformSpring.image
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)

    def update(self, arg=False):
        global a
        if not arg:
            if self.rect.y > height:
                a = random.randint(a - 304 + dude.rect.h + self.rect.h, a - self.rect.h - 1)
                self.rect.x, self.rect.y = random.randint(0, width - self.rect.w), a
        else:
            dude.vertikal_speed = -30


class PlatformMove(Platform):
    image = load_image("platform_moving.png")

    def __init__(self, x, y):
        super().__init__(x, y)
        self.image = PlatformMove.image
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = 3

    def update(self, arg=False):
        global a
        if not arg:
            if self.rect.y > height:
                a = random.randint(a - 304 + dude.rect.h + self.rect.h, a - self.rect.h - 1)
                self.rect.x, self.rect.y = random.randint(0, width - self.rect.w), a
            if self.rect.x + self.rect[2] >= width:
                self.speed = -3
            if self.rect.x <= 0:
                self.speed = 3
            self.rect.x += self.speed


#ДОДЕЛАТЬ
class Shell(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__(all_sprites)
        self.image = Platform.image
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = dude.rect.x + dude.rect[2] // 2
        self.rect.y = dude.rect.y

    def update(self, *args):
        pass
#ДОДЕЛАТЬ


class Doodle(pygame.sprite.Sprite):
    image = load_image("doodle.jpeg", -1)

    def __init__(self):
        super().__init__(all_sprites)
        self.image = Doodle.image
        self.rect = self.image.get_rect()
        # вычисляем маску для эффективного сравнения
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = width // 2 - self.rect[2] // 2
        self.rect.y = height - 50 - self.rect[3]
        self.y = height - 10
        self.vertikal_speed = -14
        self.horizontal_speed = 4
        self.delta = 0
        self.a1 = 0.5
        self.a2 = 0.3
        self.flipness = 0
        self.motion = None

    def update(self, *args):
        global a
        if args and args[0].type == pygame.MOUSEBUTTONDOWN:
            self.shoot(args[0].pos)
        if args and args[0].type == pygame.KEYDOWN:
            if args[0].key == 97:
                self.motion = 'A'
            if args[0].key == 100:
                self.motion = 'D'
        if args and args[0].type == pygame.KEYUP:
            if args[0].key == 97 and self.motion == 'A':
                self.motion = None
            if args[0].key == 100 and self.motion == 'D':
                self.motion = None
            self.horizontal_speed = 2
        if self.motion is not None:
            self.movement_horizontal(self.motion)
        if pygame.sprite.spritecollideany(self, platforms):
            if self.vertikal_speed > 0:
                if pygame.sprite.spritecollideany(self, platforms).__class__.__name__ != 'PlatformCrush':
                    self.vertikal_speed = -14
                pygame.sprite.spritecollideany(self, platforms).update(True)
        if camera.dy - self.rect.y > 324:
            self.delta = camera.dy - self.rect.y
            camera.update(self)
            a += camera.delta
        self.movement_vertical()

    def movement_vertical(self):
        self.rect.y += self.vertikal_speed
        self.vertikal_speed += self.a1

    def movement_horizontal(self, motion):
        if motion == 'A':
            self.rect.x -= self.horizontal_speed
            if self.rect.x + self.rect.w < 0:
                self.rect.x = width
            self.image = pygame.transform.flip(self.image, self.flipness != 0, False)
            self.flipness = 0
        if motion == 'D':
            self.rect.x += self.horizontal_speed
            if self.rect.x > width:
                self.rect.x = 0 - self.rect.w
            self.image = pygame.transform.flip(self.image, self.flipness != 1, False)
            self.flipness = 1
        self.horizontal_speed += self.a2

    def shoot(self, pos):
        pass


if __name__ == '__main__':
    P = [0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2]
    PLATFORM = [Platform, PlatformMove, PlatformSpring, PlatformCrush]
    all_sprites = pygame.sprite.Group()
    platforms = pygame.sprite.Group()
    Background()
    dude = Doodle()
    camera = Camera()
    generate()
    running = True
    clock = pygame.time.Clock()
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                dude.update(event)
            elif event.type == pygame.KEYDOWN:
                dude.update(event)
            elif event.type == pygame.KEYUP:
                if event.key in [97, 100]:
                    dude.update(event)
        all_sprites.draw(screen)
        platforms.draw(screen)
        platforms.update()
        all_sprites.update()
        clock = pygame.time.Clock()
        clock.tick(60)
        pygame.display.flip()
